<template>
  <div style="width: 100%; height: 100%">
    <div v-if="!loading" style="position:relative; width: 100%; height: calc(100% - 150px)" ref="widgetContainer">
      <DashboardWidget
        v-for="widget in widgets"
        :params="widget"
        :key="widget.id"
        :priority="widget.priority"
        @activated="changePriority"
        @resized="changeWidget"
        @remove="removeWidget"
      />
    </div>
    <div style="width: 100%; height: 100px">
      <button @click="restoreWidget" :disabled="disableRestore">Restore widget from bin</button>
      <button @click="sortCurrentWidgets()">Sort widget</button>
      <button @click="sortCurrentWidgets(mockWidgets)">ReInit widgets</button>
    </div>
  </div>

</template>

<script>
import DashboardWidget from '@/components/dashboard/Widget.vue';

export default {
  name: 'Home',
  components: { DashboardWidget },
  data() {
    return {
      removedWidgets: [],
      widgets: [],
      loading: false,
      mockWidgets: [
        {
          id: '0',
          width: 300,
          height: 100,
          top: 0,
          left: 0,
          active: false,
          priority: 1,
          content: {
            title: 'Title 1',
          },
        },
        {
          id: '1',
          width: 300,
          height: 100,
          top: 0,
          left: 310,
          active: false,
          priority: 2,
          content: {
            title: 'Title 2',
          },
        },
        {
          id: '2',
          width: 300,
          height: 100,
          top: 0,
          left: 620,
          active: false,
          priority: 3,
          content: {
            title: 'Title 3',
          },
        },
        {
          id: '3',
          width: 300,
          height: 100,
          top: 210,
          left: 0,
          active: false,
          priority: 4,
          content: {
            title: 'Title 4',
          },
        },
        {
          id: '4',
          width: 300,
          height: 100,
          top: 210,
          left: 310,
          active: false,
          priority: 5,
          content: {
            title: 'Title 5',
          },
        },
      ],
    };
  },
  computed: {
    disableRestore() {
      return !this.removedWidgets.length;
    },
  },
  mounted() {
    try {
      this.widgets = this.restoreWidgetsFromLocalStorage();
    } catch (e) {
      this.sortCurrentWidgets(this.mockWidgets);
    }
  },
  methods: {
    sortWidgets(widgets) {
      const locWidgets = JSON.parse(JSON.stringify(widgets));
      let currentTop = 0;
      let currentLeft = 0;
      this.loading = true;
      locWidgets.map((w) => {
        if ((currentLeft + w.width) < +this.$refs.widgetContainer.clientWidth) {
          w.top = currentTop < 0 ? 0 : currentTop;
          w.left = currentLeft < 0 ? 0 : currentLeft;
          currentLeft += w.width + 10;
        } else {
          currentTop += w.height + 10;
          currentLeft = 0;
          w.top = currentTop < 0 ? 0 : currentTop;
          w.left = currentLeft < 0 ? 0 : currentLeft;
        }
        w.active = false;
        return w;
      });
      setTimeout(() => {
        this.loading = false;
      }, 0);
      return locWidgets;
    },
    sortCurrentWidgets(widgets) {
      this.widgets = this.sortWidgets(widgets || this.widgets);
      this.saveWidgetsToLocalStorage();
    },
    changePriority(widgetId) {
      const activeWidget = JSON.parse(JSON.stringify(this.widgets.filter((w) => w.id === widgetId)[0]));
      this.widgets = this.widgets.map((w) => {
        w.active = false;
        if (w.id === widgetId) {
          w.priority = this.widgets.length;
          w.active = true;
        } else if (w.priority >= activeWidget.priority) {
          w.priority -= 1;
        }
        return w;
      });
      this.saveWidgetsToLocalStorage();
    },
    changeWidget(widgetId, rect) {
      if (!this.loading) {
        const activeWidgetIndex = this.widgets.findIndex((w) => w.id === widgetId);
        Object.assign(this.widgets[activeWidgetIndex], rect);
        this.saveWidgetsToLocalStorage();
      }
    },
    removeWidget(widgetId) {
      const activeWidgetIndex = this.widgets.findIndex((w) => w.id === widgetId);
      this.removedWidgets.push(this.widgets.splice(activeWidgetIndex, 1));
      this.saveWidgetsToLocalStorage();
    },
    restoreWidget() {
      const restoredWidget = this.removedWidgets.pop()[0];
      this.widgets.push(this.widgetToDefaultParams(restoredWidget));
      this.saveWidgetsToLocalStorage();
    },
    widgetToDefaultParams(widget) {
      const widgetContainer = {
        height: +this.$refs.widgetContainer.clientHeight,
        width: +this.$refs.widgetContainer.clientWidth,
      };
      widget.left = widgetContainer.width / 2 - 150;
      widget.top = widgetContainer.height / 2 - 50;
      widget.width = 300;
      widget.height = 100;
      widget.active = false;
      return widget;
    },
    saveWidgetsToLocalStorage() {
      localStorage.setItem('widgets', JSON.stringify(this.widgets));
    },
    restoreWidgetsFromLocalStorage() {
      if (localStorage.getItem('widgets') === null) {
        throw new Error();
      }
      return JSON.parse(localStorage.getItem('widgets'));
    },
  },
};
</script>
